import java.io.*;
import java.util.*;
class project
{
public static void main(String[] args)
{
Scanner cs=new Scanner(System.in);
int a,b,n,cf1=1,cf2=1,avg,c=0,i,j;
System.out.println("Enter 2 numbers");
a=cs.nextInt();
b=cs.nextInt();
if(a<b)
n=a;
else
n=b;

for(i=1;i<=n;i++)
{
if(a%i==0&&b%i==0)
{
c++;
cf1=cf2;
cf2=i;
}
}

if(c>=2)
{
for(i=1;i<=cf1;i++)
{
for(j=1;j<=cf2;j++)
{
System.out.print("*");
}
System.out.println();
}
}
else if(c<2)
{
avg=(a+b)/2;
for(i=1;i<=avg;i++)
{
System.out.print("*");
}
}
}
}